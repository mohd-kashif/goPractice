package repositories

import (
	"goPractice/flipfit/constant"
	"goPractice/flipfit/models"
)

type SlotRepo struct {
	Slots map[int]models.Slot
}

func NewSlotRepo() SlotRepo {
	return SlotRepo{
		Slots: map[int]models.Slot{},
	}
}

func (s *SlotRepo) AddSlot(startHour int, startMinute int, capacity int, workoutType constant.WORKOUT_TYPE, waitingListCapacity int) int {
	slot := models.NewSlot(startHour, startMinute, capacity, workoutType, waitingListCapacity)
	s.Slots[slot.ID] = slot
	return slot.ID
}
