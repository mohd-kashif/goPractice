package repositories

import "goPractice/flipfit/models"

type UserRepo struct {
	Users map[int]models.User
}

func NewUserRepo() UserRepo {
	return UserRepo{
		Users: map[int]models.User{},
	}
}

func (u *UserRepo) AddUser(name string, cityID int) int {
	user := models.NewUser(name, cityID)
	u.Users[user.ID] = user
	return user.ID
}
