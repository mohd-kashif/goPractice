package repositories

import (
	"goPractice/flipfit/models"
)

type CenterRepo struct {
	Centers map[int]models.Center
}

func NewCenterRepo() CenterRepo {
	return CenterRepo{
		Centers: map[int]models.Center{},
	}
}

func (c *CenterRepo) AddCenter(name string, latitude float32, longitude float32, numberOfSlots int, cityID int) int {
	center := models.NewCenter(name, latitude, longitude, numberOfSlots, cityID)
	c.Centers[center.ID] = center

	return center.ID
}

func (c *CenterRepo) IsCenterExist(centerID int) bool {
	_, found := c.Centers[centerID]
	return found
}
