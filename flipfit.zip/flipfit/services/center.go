package services

import (
	"goPractice/flipfit/repositories"
)

type CenterService struct {
	CenterRepo repositories.CenterRepo
}

func NewCenterRepo() CenterService {
	return CenterService{
		CenterRepo: repositories.CenterRepo{},
	}
}

func (c *CenterService) AddCenter(cityID int, name string, latitude float32, longitude float32, numberOfSlots int) int {
	centerID := c.CenterRepo.AddCenter(name, latitude, longitude, numberOfSlots, cityID)
	return centerID
}

func (c *CenterService) IsCenterExist(centerID int) bool {
	return c.CenterRepo.IsCenterExist(centerID)
}
