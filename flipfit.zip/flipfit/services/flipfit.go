package services

import (
	"errors"
	"goPractice/flipfit/repositories"
)

type FlipfitService struct {
	FlipfitRepo   repositories.CityRepo
	CenterService CenterService
}

func NewFlipfitService() FlipfitService {
	return FlipfitService{
		FlipfitRepo: repositories.CityRepo{},
	}
}

func (f *FlipfitService) AddCity(cityName string) (int, error) {
	cityID, err := f.FlipfitRepo.AddCity(cityName)
	if err != nil {
		return 0, err
	}

	return cityID, nil
}

func (f *FlipfitService) AddCenter(cityID int, name string, latitude float32, longitude float32, numberOfSlots int) (int, error) {
	if !f.IsCityExist(cityID) {
		return 0, errors.New("city does not exist")
	}
	centerID := f.CenterService.AddCenter(cityID, name, latitude, longitude, numberOfSlots)

	return centerID, nil
}

func (f *FlipfitService) IsCityExist(cityID int) bool {
	return f.FlipfitRepo.IsCityExist(cityID)
}

func (f *FlipfitService) AddSlot(centerID int, workoutType string, startHour int, startMinute int, capacity int, waitingListSize int) (int, error) {
	centerExist := f.CenterService.IsCenterExist(centerID)
	if !centerExist {
		return 0, errors.New("no center found")
	}
	return 0, nil
}
