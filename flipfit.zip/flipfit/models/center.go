package models

var centerID = 0

type Center struct {
	ID            int
	Name          string
	Latitude      float32
	Longitude     float32
	NumberOfSlots int
	CityID        int
	Slots         map[string][]Slot
	ActiveSlots   int
}

func NewCenter(name string, latitude float32, longitude float32, numberOfSlots int, cityID int) Center {
	id := getNextCenterID()
	return Center{
		ID:            id,
		Name:          name,
		Latitude:      latitude,
		Longitude:     longitude,
		NumberOfSlots: numberOfSlots,
		CityID:        cityID,
		Slots:         make(map[string][]Slot),
		ActiveSlots:   0,
	}
}

func getNextCenterID() int {
	centerID++
	return centerID
}

func (c *Center) AddSlot(slot Slot) bool {
	if c.ActiveSlots >= c.NumberOfSlots {
		return false
	}
	workoutSlots := c.Slots[string(slot.WorkoutType)]
	for _, workoutSlot := range workoutSlots {
		if (workoutSlot.EndTime) > slot.StartTime && workoutSlot.Status == 1 {
			return false
		}
	}
	c.Slots[string(slot.WorkoutType)] = append(c.Slots[string(slot.WorkoutType)], slot)
	return true
}
