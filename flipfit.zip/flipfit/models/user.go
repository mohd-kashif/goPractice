package models

var userID = 0

type User struct {
	ID          int
	Name        string
	BookedSlots map[int][]int
	CityID      int
}

func NewUser(name string, cityID int) User {
	id := getNextUserID()
	return User{
		ID:          id,
		Name:        name,
		BookedSlots: map[int][]int{},
		CityID:      cityID,
	}
}

func getNextUserID() int {
	userID++
	return userID
}
