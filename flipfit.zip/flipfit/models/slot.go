package models

import "goPractice/flipfit/constant"

var slotID = 0

type Slot struct {
	ID                  int
	StartTime           int
	EndTime             int
	Status              int
	Capacity            int
	WaitingListCapacity int
	WorkoutType         constant.WORKOUT_TYPE
	WaitingList         []int
}

func NewSlot(startHour int, startMinute int, capacity int, workoutType constant.WORKOUT_TYPE, waitingListCapacity int) Slot {
	id := getNextSlotID()
	startTime := startHour*60 + startMinute
	endTime := (startHour+1)*60 + startMinute
	return Slot{
		ID:                  id,
		StartTime:           startTime,
		EndTime:             endTime,
		Status:              1,
		Capacity:            capacity,
		WaitingListCapacity: waitingListCapacity,
		WorkoutType:         workoutType,
		WaitingList:         []int{},
	}
}

func getNextSlotID() int {
	slotID++
	return slotID
}

func (s *Slot) Enqueue(memberID int) bool {
	if len(s.WaitingList) < s.WaitingListCapacity {
		s.WaitingList = append(s.WaitingList, memberID)
		return true
	}
	return false
}

func (s *Slot) Dequeue() (int, bool) {
	if len(s.WaitingList) == 0 {
		return 0, false
	}
	memberID := s.WaitingList[0]
	s.WaitingList = s.WaitingList[1:]
	return memberID, true
}
